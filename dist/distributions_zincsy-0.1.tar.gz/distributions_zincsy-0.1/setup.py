from setuptools import setup

setup(name='distributions_zincsy',
      version='0.1',
      description='Gaussian distributions and Binomial Distributions',
      packages=['distributions_zincsy'],
      author_email = 'saurabh.zingade@gmail.com',
      author='Saurabh Zingade',
      zip_safe=False)
